import React, { useState } from 'react';
import { runTestCase } from '../services/geminiService';
import { TestCase } from '../types';
import { Play, RotateCw, CheckCircle, XCircle, Clock, Plus, Trash2, Download } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const INITIAL_TEST_CASES: TestCase[] = [
  {
    id: 'tc-1',
    prompt: 'What is the capital of France? Reply with just the city name.',
    expectedCriteria: 'Must contain "Paris". Must be concise.',
    status: 'PENDING'
  },
  {
    id: 'tc-2',
    prompt: 'Write a Python function to add two numbers.',
    expectedCriteria: 'Must contain "def" and "return". Valid Python syntax.',
    status: 'PENDING'
  },
  {
    id: 'tc-3',
    prompt: 'Who is the CEO of Google as of 2024?',
    expectedCriteria: 'Must mention Sundar Pichai.',
    status: 'PENDING'
  },
  {
    id: 'tc-4',
    prompt: 'Translate "Hello" to Spanish.',
    expectedCriteria: 'Must be "Hola".',
    status: 'PENDING'
  },
  {
    id: 'tc-5',
    prompt: 'What is 2 + 2?',
    expectedCriteria: 'Result must be 4.',
    status: 'PENDING'
  }
];

export const RegressionSuite: React.FC = () => {
  const [testCases, setTestCases] = useState<TestCase[]>(INITIAL_TEST_CASES);
  const [isRunning, setIsRunning] = useState(false);
  
  // Form State
  const [isAdding, setIsAdding] = useState(false);
  const [newPrompt, setNewPrompt] = useState('');
  const [newCriteria, setNewCriteria] = useState('');

  const runSuite = async () => {
    setIsRunning(true);
    // Reset statuses
    setTestCases(prev => prev.map(tc => ({ ...tc, status: 'PENDING', actualOutput: undefined, reasoning: undefined })));

    // Run sequentially for visual effect, though parallel is faster
    for (let i = 0; i < testCases.length; i++) {
        const currentId = testCases[i].id;
        
        // Mark running
        setTestCases(prev => prev.map(tc => tc.id === currentId ? { ...tc, status: 'RUNNING' } : tc));
        
        try {
            const updated = await runTestCase(testCases[i]);
            setTestCases(prev => prev.map(tc => tc.id === currentId ? updated : tc));
        } catch (e) {
            console.error(e);
            setTestCases(prev => prev.map(tc => tc.id === currentId ? { ...tc, status: 'FAIL', reasoning: 'API Error' } : tc));
        }
    }
    setIsRunning(false);
  };

  const handleAddTestCase = () => {
    if (!newPrompt.trim() || !newCriteria.trim()) return;

    const newCase: TestCase = {
      id: `tc-${Date.now()}`,
      prompt: newPrompt,
      expectedCriteria: newCriteria,
      status: 'PENDING'
    };

    setTestCases([...testCases, newCase]);
    setNewPrompt('');
    setNewCriteria('');
    setIsAdding(false);
  };

  const deleteTestCase = (id: string) => {
    setTestCases(testCases.filter(tc => tc.id !== id));
  };

  const exportToCSV = () => {
    const headers = ['ID', 'Status', 'Prompt', 'Expected Criteria', 'Actual Output', 'Analysis'];
    const csvRows = [headers.join(',')];

    for (const tc of testCases) {
      const row = [
        tc.id,
        tc.status,
        `"${tc.prompt.replace(/"/g, '""')}"`, // Escape quotes
        `"${tc.expectedCriteria.replace(/"/g, '""')}"`,
        `"${(tc.actualOutput || '').replace(/"/g, '""')}"`,
        `"${(tc.reasoning || '').replace(/"/g, '""')}"`
      ];
      csvRows.push(row.join(','));
    }

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `regression-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const passCount = testCases.filter(tc => tc.status === 'PASS').length;
  const failCount = testCases.filter(tc => tc.status === 'FAIL').length;
  const pendingCount = testCases.filter(tc => tc.status === 'PENDING' || tc.status === 'RUNNING').length;
  const total = testCases.length;
  
  const chartData = [
      { name: 'Pass', value: passCount, color: '#22c55e' },
      { name: 'Fail', value: failCount, color: '#ef4444' },
      { name: 'Pending', value: pendingCount, color: '#cbd5e1' },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Regression Testing Suite</h2>
          <p className="text-slate-600">
            Systematic automated testing to detect regressions and validate model behavior against expected criteria.
          </p>
        </div>
        <div className="flex gap-3">
             <button
                onClick={exportToCSV}
                className="flex items-center gap-2 px-4 py-3 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50 font-medium transition-all shadow-sm"
                title="Download CSV Report"
            >
                <Download size={18} />
                <span className="hidden sm:inline">Export</span>
            </button>
             <button
                onClick={() => setIsAdding(!isAdding)}
                disabled={isRunning}
                className={`flex items-center gap-2 px-4 py-3 rounded-lg border font-medium transition-all shadow-sm
                    ${isAdding ? 'bg-slate-100 border-slate-300 text-slate-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
            >
                <Plus size={18} />
                {isAdding ? 'Cancel' : 'Add Case'}
            </button>
            <button
                onClick={runSuite}
                disabled={isRunning}
                className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 font-medium transition-all shadow-sm"
            >
                {isRunning ? <RotateCw className="animate-spin" /> : <Play fill="currentColor" />}
                {isRunning ? 'Running Suite...' : 'Run Suite'}
            </button>
        </div>
      </div>

      {/* Add New Case Form */}
      {isAdding && (
          <div className="bg-white p-6 rounded-xl border border-blue-200 shadow-sm animate-fade-in ring-4 ring-blue-50/50">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Plus size={18} className="text-blue-500" />
                Add New Test Case
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                        Input Prompt
                    </label>
                    <input 
                        type="text"
                        value={newPrompt}
                        onChange={(e) => setNewPrompt(e.target.value)}
                        placeholder="e.g. Write a haiku about clouds"
                        className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
                        autoFocus
                    />
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                        Expected Criteria
                    </label>
                    <div className="flex gap-2">
                        <input 
                            type="text"
                            value={newCriteria}
                            onChange={(e) => setNewCriteria(e.target.value)}
                            placeholder="e.g. Must follow 5-7-5 structure"
                            className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
                            onKeyDown={(e) => e.key === 'Enter' && handleAddTestCase()}
                        />
                         <button 
                            onClick={handleAddTestCase}
                            disabled={!newPrompt.trim() || !newCriteria.trim()}
                            className="px-6 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 font-medium transition-colors"
                        >
                            Save
                        </button>
                    </div>
                </div>
            </div>
          </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Stats Card */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm lg:col-span-1 flex flex-col justify-between">
            <div>
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-6">Suite Status</h3>
                <div className="space-y-4">
                    <div className="flex justify-between items-center">
                        <span className="text-slate-600">Passed</span>
                        <span className="text-green-600 font-bold text-xl">{passCount}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-slate-600">Failed</span>
                        <span className="text-red-600 font-bold text-xl">{failCount}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-slate-600">Total Cases</span>
                        <span className="text-slate-800 font-bold text-xl">{total}</span>
                    </div>
                </div>
            </div>
            <div className="h-40 mt-6">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                        <XAxis dataKey="name" hide />
                        <Tooltip cursor={{fill: 'transparent'}} />
                        <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                            {chartData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>

        {/* Test Cases List */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm lg:col-span-3 overflow-hidden flex flex-col">
            <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                            <th className="p-4 w-16">Status</th>
                            <th className="p-4 w-1/4">Prompt</th>
                            <th className="p-4 w-1/4">Expected Criteria</th>
                            <th className="p-4">Actual Output & Analysis</th>
                            <th className="p-4 w-10"></th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {testCases.map((tc) => (
                            <tr key={tc.id} className="hover:bg-slate-50 transition-colors group">
                                <td className="p-4 align-top">
                                    {tc.status === 'PENDING' && <div className="w-6 h-6 rounded-full border-2 border-slate-200 flex items-center justify-center"><Clock size={14} className="text-slate-300"/></div>}
                                    {tc.status === 'RUNNING' && <RotateCw className="text-blue-500 animate-spin" size={24} />}
                                    {tc.status === 'PASS' && <CheckCircle className="text-green-500" size={24} />}
                                    {tc.status === 'FAIL' && <XCircle className="text-red-500" size={24} />}
                                </td>
                                <td className="p-4 align-top text-sm font-medium text-slate-800">
                                    {tc.prompt}
                                </td>
                                <td className="p-4 align-top text-sm text-slate-600">
                                    {tc.expectedCriteria}
                                </td>
                                <td className="p-4 align-top text-sm">
                                    {tc.actualOutput ? (
                                        <div className="space-y-2">
                                            <div className="bg-slate-100 p-2 rounded text-slate-700 font-mono text-xs max-h-24 overflow-y-auto">
                                                {tc.actualOutput}
                                            </div>
                                            {tc.reasoning && (
                                                <div className={`text-xs italic ${tc.status === 'PASS' ? 'text-green-700' : 'text-red-700'}`}>
                                                    Analysis: {tc.reasoning}
                                                </div>
                                            )}
                                        </div>
                                    ) : (
                                        <span className="text-slate-400 italic">Waiting to run...</span>
                                    )}
                                </td>
                                <td className="p-4 align-top">
                                    <button 
                                        onClick={() => deleteTestCase(tc.id)}
                                        className="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                        title="Remove test case"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
      </div>
    </div>
  );
};
