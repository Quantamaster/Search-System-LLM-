import React, { useState } from 'react';
import { detectHallucination } from '../services/geminiService';
import { EvaluationResult } from '../types';
import { Search, ShieldAlert, CheckCircle2, HelpCircle, FileText, AlertTriangle } from 'lucide-react';

const DEFAULT_CONTEXT = `The Apollo 11 mission was the first spaceflight that landed the first two people on the Moon. Commander Neil Armstrong and lunar module pilot Buzz Aldrin, both American, landed the Apollo Lunar Module Eagle on July 20, 1969, at 20:17 UTC. Armstrong became the first person to step onto the lunar surface six hours and 39 minutes later on July 21 at 02:56 UTC; Aldrin joined him 19 minutes later. They spent about two and a quarter hours together outside the spacecraft, and they collected 47.5 pounds (21.5 kg) of lunar material to bring back to Earth. Michael Collins piloted the Command Module Columbia alone in lunar orbit while they were on the Moon's surface.`;

export const HallucinationDetector: React.FC = () => {
  const [context, setContext] = useState(DEFAULT_CONTEXT);
  const [claim, setClaim] = useState('Michael Collins walked on the moon for 19 minutes.');
  const [result, setResult] = useState<EvaluationResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleCheck = async () => {
    if (!context || !claim) return;
    setLoading(true);
    try {
      const res = await detectHallucination(context, claim);
      setResult(res);
    } catch (e) {
      console.error(e);
      alert('Verification failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Hallucination Detector</h2>
        <p className="text-slate-600">
          Verify statements against a strict reference context to detect fabrications or distortions.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
            {/* Input Section */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-3">
                    <FileText size={16} /> Reference Context (Ground Truth)
                </label>
                <textarea
                    value={context}
                    onChange={(e) => setContext(e.target.value)}
                    className="w-full h-48 p-3 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                    placeholder="Paste the source text here..."
                />
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-3">
                    <AlertTriangle size={16} /> Claim to Verify
                </label>
                <textarea
                    value={claim}
                    onChange={(e) => setClaim(e.target.value)}
                    className="w-full h-24 p-3 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                    placeholder="Enter the statement to check..."
                />
                <button
                    onClick={handleCheck}
                    disabled={loading}
                    className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-70"
                >
                    {loading ? 'Analyzing...' : 'Verify Claim'}
                </button>
            </div>
        </div>

        <div className="space-y-6">
            {/* Results Section */}
            {result ? (
                <div className={`bg-white rounded-xl border-2 shadow-sm overflow-hidden animate-fade-in
                    ${result.verdict === 'SUPPORTED' ? 'border-green-200' : 
                      result.verdict === 'HALLUCINATION' ? 'border-red-200' : 'border-amber-200'}`}
                >
                    <div className={`p-6 text-center border-b
                        ${result.verdict === 'SUPPORTED' ? 'bg-green-50' : 
                        result.verdict === 'HALLUCINATION' ? 'bg-red-50' : 'bg-amber-50'}`}
                    >
                        {result.verdict === 'SUPPORTED' && <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-3" />}
                        {result.verdict === 'HALLUCINATION' && <ShieldAlert className="w-16 h-16 text-red-500 mx-auto mb-3" />}
                        {result.verdict === 'UNVERIFIABLE' && <HelpCircle className="w-16 h-16 text-amber-500 mx-auto mb-3" />}
                        
                        <h3 className={`text-2xl font-bold
                            ${result.verdict === 'SUPPORTED' ? 'text-green-700' : 
                            result.verdict === 'HALLUCINATION' ? 'text-red-700' : 'text-amber-700'}`}
                        >
                            {result.verdict}
                        </h3>
                        <div className="text-sm font-medium text-slate-500 mt-1">
                            Confidence: {result.confidence}%
                        </div>
                    </div>

                    <div className="p-6 space-y-4">
                        <div>
                            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Analysis</h4>
                            <p className="text-slate-700 leading-relaxed">
                                {result.reasoning}
                            </p>
                        </div>

                        {result.citations && result.citations.length > 0 && (
                             <div>
                                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Supporting Evidence</h4>
                                <ul className="space-y-2">
                                    {result.citations.map((cite, i) => (
                                        <li key={i} className="bg-slate-50 p-3 rounded-md text-sm text-slate-600 border border-slate-100 italic">
                                            "{cite}"
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                </div>
            ) : (
                <div className="h-full bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-400 p-8">
                    <Search size={48} className="mb-4 opacity-50" />
                    <p className="text-center">Enter context and a claim to begin fact-checking.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};
