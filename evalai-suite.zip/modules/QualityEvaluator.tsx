import React, { useState } from 'react';
import { generateVariations, evaluateResponses } from '../services/geminiService';
import { GeneratedResponse } from '../types';
import { Loader2, Zap, Award, BarChart3 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export const QualityEvaluator: React.FC = () => {
  const [prompt, setPrompt] = useState('Explain the concept of "entropy" to a high school student using an analogy.');
  const [responses, setResponses] = useState<GeneratedResponse[]>([]);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'IDLE' | 'GENERATING' | 'EVALUATING' | 'DONE'>('IDLE');

  const handleRun = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setResponses([]);
    
    try {
      setStep('GENERATING');
      const vars = await generateVariations(prompt);
      setResponses(vars);
      
      setStep('EVALUATING');
      const evaluated = await evaluateResponses(prompt, vars);
      setResponses(evaluated);
      
      setStep('DONE');
    } catch (e) {
      console.error(e);
      alert('Error running evaluation. Check API Key.');
    } finally {
      setLoading(false);
    }
  };

  const getWinner = () => {
    if (responses.length === 0 || !responses[0].scores) return null;
    return responses.reduce((prev, current) => {
      const prevScore = (prev.scores?.accuracy || 0) + (prev.scores?.tone || 0) + (prev.scores?.coherence || 0);
      const currScore = (current.scores?.accuracy || 0) + (current.scores?.tone || 0) + (current.scores?.coherence || 0);
      return (currScore > prevScore) ? current : prev;
    });
  };

  const winner = getWinner();

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Quality Evaluator</h2>
        <p className="text-slate-600 mb-6">
          Automatically generate diverse LLM responses and use an AI Judge to score them on Accuracy, Tone, and Coherence.
        </p>

        <div className="flex gap-4">
          <textarea 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="flex-1 p-4 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none h-32"
            placeholder="Enter a prompt to evaluate..."
          />
          <button
            onClick={handleRun}
            disabled={loading}
            className="px-8 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium transition-colors flex flex-col items-center justify-center min-w-[140px]"
          >
            {loading ? <Loader2 className="animate-spin mb-2" /> : <Zap className="mb-2" />}
            {loading ? (step === 'GENERATING' ? 'Generating...' : 'Judging...') : 'Run Evaluation'}
          </button>
        </div>
      </div>

      {responses.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {responses.map((resp) => {
             const isWinner = winner?.id === resp.id && step === 'DONE';
             const totalScore = resp.scores ? Math.round((resp.scores.accuracy + resp.scores.tone + resp.scores.coherence) / 3) : 0;

             return (
              <div 
                key={resp.id} 
                className={`relative bg-white rounded-xl border-2 overflow-hidden transition-all duration-300 ${isWinner ? 'border-amber-400 shadow-lg ring-4 ring-amber-50' : 'border-slate-200'}`}
              >
                {isWinner && (
                  <div className="absolute top-0 right-0 bg-amber-400 text-white text-xs font-bold px-3 py-1 rounded-bl-lg flex items-center gap-1">
                    <Award size={14} /> WINNER
                  </div>
                )}
                
                <div className="p-5">
                  <div className="flex justify-between items-center mb-4">
                    <span className="font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-full text-sm">
                      {resp.modelName}
                    </span>
                    {step === 'DONE' && (
                        <div className="text-2xl font-black text-slate-800">
                            {totalScore}<span className="text-xs text-slate-400 font-normal">/100</span>
                        </div>
                    )}
                  </div>

                  <div className="prose prose-sm text-slate-600 mb-6 h-48 overflow-y-auto pr-2 custom-scrollbar">
                    {resp.content}
                  </div>

                  {step === 'DONE' && resp.scores && (
                    <div className="space-y-3 pt-4 border-t border-slate-100">
                      <div className="flex items-center text-xs font-medium text-slate-500 mb-2">
                        <BarChart3 size={14} className="mr-1" /> AI EVALUATION
                      </div>
                      
                      <ScoreBar label="Accuracy" value={resp.scores.accuracy} />
                      <ScoreBar label="Tone" value={resp.scores.tone} />
                      <ScoreBar label="Coherence" value={resp.scores.coherence} />
                      
                      <div className="mt-4 p-3 bg-slate-50 rounded text-xs text-slate-600 italic">
                        "{resp.reasoning}"
                      </div>
                    </div>
                  )}
                  {step !== 'DONE' && (
                    <div className="h-40 flex items-center justify-center text-slate-400 text-sm animate-pulse">
                      Waiting for judge...
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

const ScoreBar = ({ label, value }: { label: string, value: number }) => (
  <div className="flex items-center gap-3">
    <div className="w-20 text-xs text-slate-600 font-medium">{label}</div>
    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
      <div 
        className={`h-full rounded-full ${value > 80 ? 'bg-green-500' : value > 60 ? 'bg-yellow-500' : 'bg-red-500'}`} 
        style={{ width: `${value}%` }}
      />
    </div>
    <div className="w-8 text-right text-xs font-bold text-slate-700">{value}</div>
  </div>
);
