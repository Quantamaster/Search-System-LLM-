import React from 'react';
import { ModuleType } from '../types';
import { LayoutDashboard, CheckCircle, Search, ShieldCheck } from 'lucide-react';

interface SidebarProps {
  activeModule: ModuleType;
  setActiveModule: (m: ModuleType) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeModule, setActiveModule }) => {
  const navItems = [
    {
      id: ModuleType.QUALITY_EVALUATOR,
      label: 'Quality Evaluator',
      icon: <Search size={20} />,
      desc: 'Compare & Score LLM Outputs'
    },
    {
      id: ModuleType.HALLUCINATION_DETECTOR,
      label: 'Fact Checker',
      icon: <ShieldCheck size={20} />,
      desc: 'Detect Hallucinations'
    },
    {
      id: ModuleType.REGRESSION_SUITE,
      label: 'Regression Suite',
      icon: <CheckCircle size={20} />,
      desc: 'Automated Testing Pipeline'
    }
  ];

  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col h-screen fixed left-0 top-0 shadow-xl z-10">
      <div className="p-6 border-b border-slate-700">
        <div className="flex items-center gap-2">
            <LayoutDashboard className="text-blue-400" />
            <h1 className="text-xl font-bold tracking-tight">EvalAI Suite</h1>
        </div>
        <p className="text-xs text-slate-400 mt-2">LLM Evaluation Toolkit</p>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveModule(item.id)}
            className={`w-full flex items-start p-3 rounded-lg transition-all duration-200 group text-left
              ${activeModule === item.id 
                ? 'bg-blue-600 text-white shadow-md' 
                : 'hover:bg-slate-800 text-slate-300'
              }`}
          >
            <div className="mt-1 mr-3">{item.icon}</div>
            <div>
              <div className="font-medium">{item.label}</div>
              <div className={`text-xs mt-1 ${activeModule === item.id ? 'text-blue-100' : 'text-slate-500 group-hover:text-slate-400'}`}>
                {item.desc}
              </div>
            </div>
          </button>
        ))}
      </nav>

      <div className="p-4 bg-slate-950 text-xs text-slate-500">
        <p>Built with Gemini 2.5</p>
        <p className="mt-1">© 2025 EvalAI</p>
      </div>
    </div>
  );
};