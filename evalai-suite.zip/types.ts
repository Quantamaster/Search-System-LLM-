export enum ModuleType {
  QUALITY_EVALUATOR = 'QUALITY_EVALUATOR',
  HALLUCINATION_DETECTOR = 'HALLUCINATION_DETECTOR',
  REGRESSION_SUITE = 'REGRESSION_SUITE'
}

export interface GeneratedResponse {
  id: string;
  modelName: string; // Simulated model name
  content: string;
  scores?: {
    accuracy: number;
    tone: number;
    coherence: number;
  };
  reasoning?: string;
}

export interface EvaluationResult {
  verdict: 'SUPPORTED' | 'HALLUCINATION' | 'UNVERIFIABLE';
  confidence: number;
  reasoning: string;
  citations: string[];
}

export interface TestCase {
  id: string;
  prompt: string;
  expectedCriteria: string;
  status: 'PENDING' | 'PASS' | 'FAIL' | 'RUNNING';
  actualOutput?: string;
  reasoning?: string;
}
