import { GoogleGenAI, Type, Schema } from "@google/genai";
import { GeneratedResponse, EvaluationResult, TestCase } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_FAST = 'gemini-2.5-flash';

// --- Assignment 1: Quality Evaluator ---

export const generateVariations = async (prompt: string): Promise<GeneratedResponse[]> => {
  const response = await ai.models.generateContent({
    model: MODEL_FAST,
    contents: `Generate 3 distinct responses to the following prompt: "${prompt}". 
    Make them vary slightly in tone (e.g., one formal, one casual, one concise). 
    Return a JSON array where each object has 'content' (string) and 'modelName' (a creative name for the style, e.g., 'FormalBot').`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            modelName: { type: Type.STRING },
            content: { type: Type.STRING }
          },
          required: ["modelName", "content"]
        }
      } as Schema
    }
  });

  const raw = JSON.parse(response.text || "[]");
  return raw.map((r: any, idx: number) => ({
    id: `resp-${idx}`,
    modelName: r.modelName,
    content: r.content
  }));
};

export const evaluateResponses = async (prompt: string, responses: GeneratedResponse[]): Promise<GeneratedResponse[]> => {
  const responsesText = responses.map(r => `Model ${r.modelName}: ${r.content}`).join('\n---\n');
  
  const response = await ai.models.generateContent({
    model: MODEL_FAST,
    contents: `You are an expert LLM Evaluator.
    Original Prompt: "${prompt}"
    
    Evaluate the following 3 responses based on Accuracy, Tone, and Coherence.
    Assign a score from 0-100 for each metric.
    Provide a brief reasoning for your evaluation.
    
    Responses to evaluate:
    ${responsesText}
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            modelName: { type: Type.STRING },
            accuracy: { type: Type.NUMBER },
            tone: { type: Type.NUMBER },
            coherence: { type: Type.NUMBER },
            reasoning: { type: Type.STRING }
          },
          required: ["modelName", "accuracy", "tone", "coherence", "reasoning"]
        }
      } as Schema
    }
  });

  const evaluations = JSON.parse(response.text || "[]");

  // Merge evaluations back into responses
  return responses.map(r => {
    const evalData = evaluations.find((e: any) => e.modelName === r.modelName);
    if (evalData) {
      return {
        ...r,
        scores: {
          accuracy: evalData.accuracy,
          tone: evalData.tone,
          coherence: evalData.coherence
        },
        reasoning: evalData.reasoning
      };
    }
    return r;
  });
};

// --- Assignment 2: Hallucination Detector ---

export const detectHallucination = async (context: string, claim: string): Promise<EvaluationResult> => {
  const response = await ai.models.generateContent({
    model: MODEL_FAST,
    contents: `You are a strict Fact Checking AI.
    Your task is to verify if the CLAIM is supported by the REFERENCE CONTEXT.
    
    REFERENCE CONTEXT:
    """${context}"""
    
    CLAIM:
    """${claim}"""
    
    Instructions:
    1. Determine if the claim is fully 'SUPPORTED', 'HALLUCINATION' (contradicted or fabricated), or 'UNVERIFIABLE' (not mentioned).
    2. Provide a confidence score (0-100).
    3. Explain your reasoning.
    4. Extract quote(s) from the text that support your decision (if any).
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          verdict: { type: Type.STRING, enum: ['SUPPORTED', 'HALLUCINATION', 'UNVERIFIABLE'] },
          confidence: { type: Type.NUMBER },
          reasoning: { type: Type.STRING },
          citations: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["verdict", "confidence", "reasoning", "citations"]
      } as Schema
    }
  });

  return JSON.parse(response.text || "{}");
};

// --- Assignment 3: Regression Suite ---

export const runTestCase = async (testCase: TestCase): Promise<TestCase> => {
  // 1. Get Actual Output
  const generation = await ai.models.generateContent({
    model: MODEL_FAST,
    contents: testCase.prompt
  });
  const actualOutput = generation.text || "";

  // 2. Evaluate Pass/Fail
  const evalResponse = await ai.models.generateContent({
    model: MODEL_FAST,
    contents: `You are a Regression Test Automator.
    Task: Determine if the Actual Output meets the Expected Criteria for the given Prompt.
    
    Prompt: "${testCase.prompt}"
    Expected Criteria: "${testCase.expectedCriteria}"
    Actual Output: "${actualOutput}"
    
    Does it pass? Return JSON.
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          status: { type: Type.STRING, enum: ['PASS', 'FAIL'] },
          reasoning: { type: Type.STRING }
        },
        required: ["status", "reasoning"]
      } as Schema
    }
  });

  const result = JSON.parse(evalResponse.text || "{}");

  return {
    ...testCase,
    actualOutput,
    status: result.status,
    reasoning: result.reasoning
  };
};
