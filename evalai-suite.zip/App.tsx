import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { QualityEvaluator } from './modules/QualityEvaluator';
import { HallucinationDetector } from './modules/HallucinationDetector';
import { RegressionSuite } from './modules/RegressionSuite';
import { ModuleType } from './types';

function App() {
  const [activeModule, setActiveModule] = useState<ModuleType>(ModuleType.QUALITY_EVALUATOR);

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar activeModule={activeModule} setActiveModule={setActiveModule} />
      
      <main className="flex-1 ml-64 p-8 overflow-y-auto h-screen">
        <div className="max-w-7xl mx-auto animate-fade-in-up">
          {activeModule === ModuleType.QUALITY_EVALUATOR && <QualityEvaluator />}
          {activeModule === ModuleType.HALLUCINATION_DETECTOR && <HallucinationDetector />}
          {activeModule === ModuleType.REGRESSION_SUITE && <RegressionSuite />}
        </div>
      </main>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f1f5f9; 
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1; 
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94a3b8; 
        }
        @keyframes fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.5s ease-out forwards;
        }
        .animate-fade-in-up {
            animation: fade-in 0.4s ease-out forwards;
        }
      `}</style>
    </div>
  );
}

export default App;
